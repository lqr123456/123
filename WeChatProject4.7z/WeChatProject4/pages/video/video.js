// pages/video/video.js
/**Page({

  /**
   * 页面的初始数据
   */
  /**data: {
    src: 'http://clips.vorwaerts-gmbh.de/big_buck_bunny.mp4',
    danumuList: [
      {text:'第1s出现的弹幕',color:'#ff0000',time:1},
      { text: '第2s出现的弹幕', color: '#ff0000', time: 1 }
    ]
  },
  videoContext: null,
  inputValue:'',
  onReady:function(){
    this.videoContext=wx.createVideoContext('myVideo')
  },
  bindInputBlur:function(e){
    this.inputValue=e.detail.value
  },
  bindSendDanmu:function(){
    this.videoContext.sendDanmu({
      text:this.inputValue,
      color:'#f90'
    })
  },
  bindButtonTap:function(){
    wx.chooseVideo({
      sourceType:['album','camera'],
      maxDuration:60,
      camera:'back',
      success:res=>{
        this.setData({
          src:res.tempFilePath
        })
      }
    })
  },
})**/
Page({
  data: {
    movieList: [{
      create_time: 1532519754589,
      title: '海边随拍',
      src: 'http://clips.vorwaerts-gmbh.de/big_buck_bunny.mp4'

    }, {
      create_time: 1532519777690,
      title: '勿忘心安',
        src: 'http://clips.vorwaerts-gmbh.de/big_buck_bunny.mp4'

    }, {
      create_time: 1532519734589,
      title: '点滴记忆',
        src: 'http://clips.vorwaerts-gmbh.de/big_buck_bunny.mp4'
    }]
  }
})