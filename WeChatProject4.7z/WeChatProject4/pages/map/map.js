// pages/map/map.js
Page({
  data: {
    latitude: 40.06021,
    longitude: 116.3433,
    markers: [{
      iconPath: '/images/navi.png',
      id: 0,
      latitude: 40.06021,
      longitude: 116.3433,
      width: 50,
      height: 50
    }]

  },
  markertap: function () {
    wx.openLocation({
      latitude: this.data.latitude,
      longitude: this.data.longitude,
      name: '泮河景区',
      address: '泰安市'
    })
  },
  buttonTap:function(){
    wx.getLocation({
      type:"gcj02",
      success: function(res) {
        wx.openLocation({
          latitude: 'res.latitude',
          longitude: 'res.longitude',
        })
      },
    })
  }
})